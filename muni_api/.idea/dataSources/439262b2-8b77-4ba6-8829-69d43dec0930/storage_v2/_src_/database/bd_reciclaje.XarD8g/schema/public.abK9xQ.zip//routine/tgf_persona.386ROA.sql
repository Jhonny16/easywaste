create function tgf_persona() returns trigger
  language plpgsql
as
$$
begin
  if (TG_OP = 'UPDATE') then
    insert into bitacora.persona (
      id ,
      dni ,
      nombres ,
      ap_paterno ,
      ap_materno ,
      valor ,
      user_name,
      operacion,
      dir_ip,
      usuario,
      fecha_hora
    ) values
    (
      OLD.id ,
      OLD.dni ,
      OLD.nombres ,
      OLD.ap_paterno ,
      OLD.ap_materno ,
      OLD.valor ,
      OLD.user_name ,
      'Antes de actualizar',
      inet_client_addr(),
      current_user,
      now()
    );

    insert into bitacora.persona (
      id ,
      dni ,
      nombres ,
      ap_paterno ,
      ap_materno ,
      valor ,
      user_name,
      operacion,
      dir_ip,
      usuario,
      fecha_hora
    ) values
    (
      NEW.id ,
      NEW.dni ,
      NEW.nombres ,
      NEW.ap_paterno ,
      NEW.ap_materno ,
      NEW.valor ,
      NEW.user_name ,
      'Despues de actualizar',
      inet_client_addr(),
      current_user,
      now()
    );
  elsif (TG_OP = 'INSERT') then
    insert into bitacora.persona (
      id ,
      dni ,
      nombres ,
      ap_paterno ,
      ap_materno ,
      valor ,
      user_name,
      operacion,
      dir_ip,
      usuario,
      fecha_hora
    ) values
    (
      NEW.id ,
      NEW.dni ,
      NEW.nombres ,
      NEW.ap_paterno ,
      NEW.ap_materno ,
      NEW.valor ,
      NEW.user_name ,
      'Nueva insercion',
      inet_client_addr(),
      current_user,
      now()
    );
  end if;

  return null;
end
$$;

alter function tgf_persona() owner to postgres;

