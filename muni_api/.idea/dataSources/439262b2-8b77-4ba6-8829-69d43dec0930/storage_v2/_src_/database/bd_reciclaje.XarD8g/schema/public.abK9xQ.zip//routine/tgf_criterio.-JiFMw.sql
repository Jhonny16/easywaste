create function tgf_criterio() returns trigger
  language plpgsql
as
$$
begin
 if (TG_OP = 'UPDATE') then
    insert into bitacora.criterio (
      id ,
      nombre ,
      valor,
      user_name,
      operacion,
      dir_ip,
      usuario,
      fecha_hora
    ) values
    (
      OLD.id ,
      OLD.nombre ,
      OLD.valor ,
      OLD.user_name ,
      'Antes de actualizar',
      inet_client_addr(),
      current_user,
      now()
    );

    insert into bitacora.criterio (
      id ,
      nombre ,
      valor,
      user_name,
      operacion,
      dir_ip,
      usuario,
      fecha_hora
    ) values
    (
      NEW.id ,
      NEW.nombre ,
      NEW.valor ,
      NEW.user_name ,
      'Despues de actualizar',
      inet_client_addr(),
      current_user,
      now()
    );
  elsif (TG_OP = 'INSERT') then
    insert into bitacora.criterio (
      id ,
      nombre ,
      valor,
      user_name,
      operacion,
      dir_ip,
      usuario,
      fecha_hora
    ) values
    (
      NEW.id ,
      NEW.nombre ,
      NEW.valor ,
      NEW.user_name ,
      'Nueva insercion',
      inet_client_addr(),
      current_user,
      now()
    );
  end if;

  return null;
end
$$;

alter function tgf_criterio() owner to postgres;

