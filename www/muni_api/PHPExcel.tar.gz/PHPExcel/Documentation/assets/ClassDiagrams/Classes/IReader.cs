using System;
using System.Collections.Generic;
using System.Text;

namespace ClassDiagrams
{
    public interface PHPExcel_Reader_IReader
    {
        PHPExcel reads
        {
            get;
            set;
        }
    }
}
